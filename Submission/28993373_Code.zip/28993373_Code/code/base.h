/* 
File: base.h
Author: Bhanuka Gamage
Date: 14th October 2019
StudentID - 28993373
Assignment 2
*/

// Functions Definitions for the base.c file
void initializeBaseStation();
void base();
void listenToEvents();